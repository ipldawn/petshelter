{"ciudad": [
	{
	"provincia" : "Alicante",
	"poblacion" : ["Alicante", "San Vicente", "San Juan", "Novelda", "Elche"]
	},
	{
	"provincia" : "Barcelona",
	"poblacion" : ["Barcelona", "Badalona", "Montclar", "Sabadell"]
	},
	{
	"provincia" : "Madrid",
	"poblacion" : ["Madrid", "Alcobendas", "Coslada", "El Escorial", "Getafe"]
	},
	{
	"provincia" : "Murcia",
	"poblacion" : ["Murcia", "Cartagena", "Beniel", "Fortuna", "Jumilla"]
	}
	]
}