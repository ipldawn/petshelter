
// Validación Formulario Voluntarios:

///////////////////////////////// ONCLICK ///////////////////////////////////////////
function envioForm(){


	var nombre = document.getElementById("nombre").value;
	var apellidos = document.getElementById("apellidos").value;
	var direccion = document.getElementById("direccion").value;
	var cp = document.getElementById("cp").value;
	var email = document.getElementById("email").value;
	var tlfn = document.getElementById("tlfn").value;
	var provincia = document.getElementById("provincia").value;
	var poblacion = document.getElementById("poblacion").value;
	var mensaje = document.getElementById("exampleTextarea").value;
	var dias = "";
	var diasChecked;

	for(var i = 0; i < 7; i++){

		diasChecked = document.getElementsByClassName("form-check-input")[i].checked;

		if(diasChecked == true){

			dias += document.getElementsByClassName("form-check-input")[i].value + ", ";
		}
	}
	dias = dias.substr(0, dias.length - 2); //Para eliminar ", " del final del string.


///////////////////////////////// EXPRESIONES REGULARES ///////////////////////////////////////////
	var checkEmail = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}/igm;
	var checkTlfn = /^[0-9]{9}$/;
	var checkCP = /^[0-9]{5}$/;


	if(nombre == ""){

		document.getElementById("nombre_error").style.display = "block";
	}
	else{

		document.getElementById("nombre_error").style.display = "none";
	}

	if(apellidos == ""){

		document.getElementById("apellidos_error").style.display = "block";
	}
	else{
		
		document.getElementById("apellidos_error").style.display = "none";
	}

	if(direccion == ""){

		document.getElementById("direccion_error").style.display = "block";
	}
	else{
		
		document.getElementById("direccion_error").style.display = "none";
	}

	if(cp == ""){

		document.getElementById("cp_error").style.display = "block";
	}
	else{
		
		document.getElementById("cp_error").style.display = "none";
	}

	if(email == ""){

		document.getElementById("email_error").style.display = "block";
	}
	else{
		
		document.getElementById("email_error").style.display = "none";
	}

	if(tlfn == ""){

		document.getElementById("tlfn_error").style.display = "block";
	}
	else{
		
		document.getElementById("tlfn_error").style.display = "none";
	}






	if (email != "" && checkEmail.test(email) == false){

		document.getElementById("email_error2").style.display = "block";
	}
	else{

		document.getElementById("email_error2").style.display = "none";
	}

	if (tlfn != "" && checkTlfn.test(tlfn) == false){

		document.getElementById("tlfn_error2").style.display = "block";
	}
	else{

		document.getElementById("tlfn_error2").style.display = "none";
	}


	if (cp != "" && checkCP.test(cp) == false){

		document.getElementById("cp_error2").style.display = "block";
	}
	else{

		document.getElementById("cp_error2").style.display = "none";
	}

	

	setCookie("Nombre", nombre);
	setCookie("Apellidos", apellidos);
	setCookie("Dirección", direccion);
	setCookie("Código Postal", cp);
	setCookie("Email", email);
	setCookie("Teléfono", tlfn);
	setCookie("Provincia", provincia);
	setCookie("Población", poblacion);
	setCookie("Días", dias);
	setCookie("Mensaje", mensaje);

	document.getElementById("formulario").style.display = "none";
	mostrarCookies();
}


function setCookie(c_name, value, exdays) {

	var exDate = new Date();
	exDate.setDate(exDate.getDate() + exdays);
	var c_value= value + ((exdays==null) ? "" : ";expires=" + exDate.toUTCString());
	document.cookie = c_name + "=" + c_value;

}


function mostrarCookies(){

	var divCreado = document.createElement("div");
	divCreado.style.padding = "3% 6%";
	divCreado.style.width = "50%";
	divCreado.style.color = "black";
	divCreado.style.fontSize = "26px";
	divCreado.style.borderRight = "1px solid black";
	var resultado;
	var parrafo;

	var datosCookies = ['Nombre', 'Apellidos', 'Dirección', 'Código Postal', 'Email', 'Teléfono', 'Provincia', 'Población', 'Días', 'Mensaje'];

	for(var i = 0; i < datosCookies.length; i++){

		resultado = extraerCookie(datosCookies[i]);
		parrafo = document.createElement("p");
		parrafo.innerHTML = datosCookies[i] + ": " + resultado;
		divCreado.appendChild(parrafo);
	}

	document.getElementById("contenedor").appendChild(divCreado);
	var segundoDiv = document.createElement("div");
	segundoDiv.style.width = "50%";
	segundoDiv.style.textAlign = "center";
	segundoDiv.style.paddingTop = "8%";
	document.getElementById("contenedor").appendChild(segundoDiv);

	var parrafo2 = document.createElement("p");
	parrafo2.innerHTML = "¡Bienvenido a la familia!<br />Estamos deseando recibirte con los brazos abiertos<br />y que puedas participar en nuestros proyectos de voluntariado.<br />En breve nos pondremos en contacto contigo para concretar.<br />¡Nuestros animalitos te lo agradecen!";
	parrafo2.style.paddingTop = "5%";
	parrafo2.style.fontSize = "14px";
	var encabezado = document.createElement("h2");
	encabezado.innerHTML = "¡Su solicitud ha sido enviada!";
	segundoDiv.appendChild(encabezado);
	segundoDiv.appendChild(parrafo2);

}


function extraerCookie(cookieName){

	var c_name = cookieName;
	var i,x,y,ARRcookies=document.cookie.split(";");

	for(i = 0; i < ARRcookies.length; i++){

		x=ARRcookies[i].substr(0, ARRcookies[i].indexOf("="));
		y=ARRcookies[i].substr(ARRcookies[i].indexOf("=")+1);
		x=x.replace(/^\s+|\s+$/g,"");

		if(x == c_name){

			return(y);
		}
	}
		
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////



///////////////////////////////// EVENTO DE TECLADO ///////////////////////////////////////////
var espacio = 32;
document.getElementById("nombre").addEventListener('keypress', textoBloqueo);
document.getElementById("apellidos").addEventListener('keypress', textoBloqueo);

function textoBloqueo(event){

	var codigo = event.keyCode;
	var checkLetras = comprobarLetras(codigo);

	if(!checkLetras && codigo != espacio){

		event.preventDefault();
	}
}


function comprobarLetras(codigo){

	//Se permite únicamente la introducción de letras, el espacio, y las vocales con acentos.
	if((codigo >= 65 && codigo <= 90) || (codigo >= 97 && codigo <= 122) || codigo == 241 || codigo == 209 || codigo == 225 || codigo == 233 || codigo == 237 || codigo == 243 || codigo == 250 || codigo == 193 || codigo == 201 || codigo == 205 || codigo == 211 || codigo == 218){

		return true;
	}
	else{

		return false;
	}
}



//////////////////////////////////////////////////////////////////////////////////////////////


var objetoXHR;
var jsonDoc;

function cargarDoc(provincia){

	if(window.XMLHttpRequest){

		objetoXHR = new XMLHttpRequest();
	}
	else if(window.ActiveXObject){

		objetoXHR = new ActiveXObject("Microsoft.XMLHTTP");
	}

	objetoXHR.open("GET", provincia, false);
	objetoXHR.send();

	return objetoXHR.responseText; 
}


function obtenerDatosServidor(){

	jsonDoc = cargarDoc("./js/ciudades.js");
	jsonParsed = JSON.parse(jsonDoc);

	var cantidadPadre = jsonParsed['ciudad'].length;
	var provincia = document.getElementById("provincia");
	var madrid;
	var resultado = "";
	
	for(var j = 0; j < cantidadPadre; j++){

		resultado = jsonParsed['ciudad'][j]['provincia'];
		var optionElement = document.createElement("option");
		optionElement.text = resultado;
		optionElement.value = resultado;
		provincia.appendChild(optionElement);
	}

	cargarPoblacion(provincia.value);
}


function cargarPoblacion(valor){

	var cantidadPadre = jsonParsed['ciudad'].length;
	var posicionPadre;
	for(var i = 0; i < cantidadPadre; i++){
		resultado = jsonParsed['ciudad'][i]['provincia'];
		if(resultado == valor){

			posicionPadre = i;
			var cantidadHijo = jsonParsed['ciudad'][i]['poblacion'].length;
		}
	}

	var padre = document.getElementById("poblacion");
	padre.removeChild(padre.firstChild);
	
	while (padre.hasChildNodes()) {
///////////////////////////////// USO DEL DOM ///////////////////////////////////////////
    	padre.removeChild(padre.lastChild);
	}
	

	for(var k = 0; k < cantidadHijo; k++){
///////////////////////////////// USO DEL DOM ///////////////////////////////////////////
		var optionElement = document.createElement("option");
		resultadopoblacion = jsonParsed['ciudad'][posicionPadre]['poblacion'][k];
		optionElement.text = resultadopoblacion;
		optionElement.value = resultadopoblacion;
		poblacion.appendChild(optionElement);
	}
}



///////////////////////////////////////////////////////////////////////////////////////


///////////////////////////////// EVENTO DE TECLADO ///////////////////////////////////////////
document.getElementById("exampleTextarea").addEventListener('keyup', maxCaracteres);

function maxCaracteres(event){

	var codigo = event.keyCode;
	var cantidad = document.getElementById("exampleTextarea").value.length;

	var resto = 200 - cantidad;

	document.getElementById("label_TextArea").innerHTML = "Mensaje (" + resto + " de 200)";
}


////////////////////////////////////////////////////////////////////////////////////////////


///////////////////////////////// EVENTO DE RATÓN ONMOUSEOVER ///////////////////////////////////////////
function efectoImagenIn(param){

	var gatos = param;
	gatos.style.transform = "scale(1.1)";
	gatos.style.transition = "all 0.2s ease 0.3s";
}

///////////////////////////////// EVENTO DE RATÓN ONMOUSEOUT ///////////////////////////////////////////
function efectoImagenOut(param){

	var gatos = param;
	gatos.style.transition = "all 0.2s ease-out 0.3s";
	gatos.style.transform = "scale(1.0)";
}

